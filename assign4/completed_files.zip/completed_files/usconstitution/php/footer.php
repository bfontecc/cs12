  <div id="footer" class="span-24 last">
    <p>You are currently viewing <?php echo $_SERVER['SERVER_NAME'].$_SERVER['PHP_SELF']; ?> <br /> This page was last modified on <?php echo "Last modified: " . date ("F d, Y H:i", getlastmod()); ?></p>
    <p>This XHTML version of the United States Constitution was adapted from <a href="http://www.house.gov/">U.S. House of Representatives</a> website at <a href="http://www.house.gov/house/Constitution/Constitution.html">http://www.house.gov/Constitution/Constitution.html</a>. <br/>
      <a href="http://www.archives.gov/exhibits/charters/constitution.html">Learn more about the United States Constitution at <strong>The National Archives</strong> online exhibit</a>.</p>
  </div>
</div>
</body>
</html>
