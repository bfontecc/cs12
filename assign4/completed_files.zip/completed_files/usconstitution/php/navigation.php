<div id="navigation" class="span-4">
    <ul>
      <li><a id="navarticleI" href="index.php">Article I</a></li>
      <li><a id="navarticleII" href="ii.php">Article II</a></li>
      <li><a id="navarticleIII" href="iii.php">Article III</a></li>
      <li><a id="navarticleIV" href="iv.php">Article IV</a></li>
      <li><a id="navarticleV" href="v.php">Article V</a></li>
      <li><a id="navarticleVI" href="vi.php">Article VI</a></li>
      <li><a id="navarticleVII" href="vii.php">Article VII</a></li>
      <li><a id="navarticleAmendments" href="amendments.php">Amendments</a></li>
    </ul>
</div>

