<?php
/*
 * controllers/create_account.php
 *
 * load the create_account view
 * Most of the heavy lifting here is done by controllers/register.php which views/create_account.php
 * will post to
 */

$content = 'create_account';

?>
