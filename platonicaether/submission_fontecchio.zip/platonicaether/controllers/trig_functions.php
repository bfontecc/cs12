<?php
/*
 * controllers/trig_functions
 *
 * In the future, this could contain scoring information.
 *
 * currently just loads the view/trig_functions content
 */

$content = 'trig_functions';
?>
