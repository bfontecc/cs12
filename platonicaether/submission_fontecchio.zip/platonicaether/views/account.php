<?php
/*
 * views/account.php
 *
 *
 */

echo 'hello from views/account.php';
?>
