<?php
/**
 * views/my_account.php
 *
 * This view be loaded by account.php if the user is logged in.
 * It will also be loaded if the user clicks "View Account", regardless of whether they are logged in
 *
 * 
 */
?>
	<h3>Coming Soon!</h3>
	<p>Keep track of previous scores, and maintain graphs of your progress.</p>

