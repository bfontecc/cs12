<?php
/*
 * footer html
 * includes:
 * 	well containing site info 
 * 	closing body tag and html tag
 */
?>

		<div class="well span12">
			<ul>
				<li>Bret Fontecchio
				<li>2013
			</ul>
		</div>
	</div>
	</body>
</html>
